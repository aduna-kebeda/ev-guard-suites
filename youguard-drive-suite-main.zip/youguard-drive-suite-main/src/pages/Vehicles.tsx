import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Battery, Gauge, Users, Package, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import evSuv from "@/assets/ev-suv.jpg";
import evSedan from "@/assets/ev-sedan.jpg";
import evCompact from "@/assets/ev-compact.jpg";

const Vehicles = () => {
  const vehicles = [
    {
      id: 1,
      name: "Urban SUV",
      tagline: "The Perfect Family Electric SUV",
      image: evSuv,
      price: "ETB 3,500,000",
      range: "450km",
      topSpeed: "180 km/h",
      seats: 7,
      cargo: "Large",
      highlights: [
        "Spacious 7-seater configuration",
        "Advanced safety features",
        "Panoramic sunroof",
        "All-wheel drive capability",
      ],
      whyEthiopia: "Perfect for Ethiopian families who need space, comfort, and reliability for both city drives and countryside adventures. The high ground clearance handles our diverse terrain effortlessly.",
    },
    {
      id: 2,
      name: "Executive Sedan",
      tagline: "Premium Electric Luxury",
      image: evSedan,
      price: "ETB 4,200,000",
      range: "500km",
      topSpeed: "210 km/h",
      seats: 5,
      cargo: "Medium",
      highlights: [
        "Premium leather interior",
        "Advanced autopilot features",
        "Ultra-quiet cabin",
        "Executive rear seating",
      ],
      whyEthiopia: "Ideal for executives and professionals who value sophistication and performance. The extended range ensures you can drive from Addis Ababa to Adama without charging concerns.",
    },
    {
      id: 3,
      name: "City Compact",
      tagline: "Smart Urban Mobility",
      image: evCompact,
      price: "ETB 2,800,000",
      range: "350km",
      topSpeed: "150 km/h",
      seats: 5,
      cargo: "Compact",
      highlights: [
        "Nimble city handling",
        "Affordable running costs",
        "Smart parking assist",
        "Perfect for daily commute",
      ],
      whyEthiopia: "Designed for urban professionals navigating Addis Ababa's busy streets. Economical, easy to park, and sufficient range for daily city life and weekend getaways.",
    },
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Header */}
      <section className="py-20 bg-gradient-to-b from-muted/30 to-background">
        <div className="container mx-auto px-4 text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            Our Vehicle Range
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Premium Electric Vehicles
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto animate-fade-in-up">
            Discover our carefully curated selection of electric vehicles, each designed to 
            excel on Ethiopian roads while delivering exceptional comfort, range, and style.
          </p>
        </div>
      </section>

      {/* Vehicle Listings */}
      <section className="py-12">
        <div className="container mx-auto px-4 space-y-20">
          {vehicles.map((vehicle, index) => (
            <Card 
              key={vehicle.id} 
              className="overflow-hidden animate-fade-in"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className={`grid lg:grid-cols-2 gap-0 ${index % 2 === 1 ? 'lg:grid-flow-dense' : ''}`}>
                {/* Image */}
                <div className={`relative h-80 lg:h-auto ${index % 2 === 1 ? 'lg:col-start-2' : ''}`}>
                  <img
                    src={vehicle.image}
                    alt={vehicle.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-6 left-6">
                    <Badge className="bg-background/90 text-foreground border-border">
                      {vehicle.range} Range
                    </Badge>
                  </div>
                </div>

                {/* Content */}
                <div className="p-8 lg:p-12 flex flex-col justify-center">
                  <h2 className="text-3xl md:text-4xl font-bold mb-2">{vehicle.name}</h2>
                  <p className="text-xl text-muted-foreground mb-6">{vehicle.tagline}</p>
                  <p className="text-2xl font-bold text-primary mb-8">{vehicle.price}</p>

                  {/* Specs Grid */}
                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <Battery className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Range</p>
                        <p className="font-semibold">{vehicle.range}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-secondary/10 p-2 rounded-lg">
                        <Gauge className="h-5 w-5 text-secondary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Top Speed</p>
                        <p className="font-semibold">{vehicle.topSpeed}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-accent/10 p-2 rounded-lg">
                        <Users className="h-5 w-5 text-accent" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Seats</p>
                        <p className="font-semibold">{vehicle.seats}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 p-2 rounded-lg">
                        <Package className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Cargo</p>
                        <p className="font-semibold">{vehicle.cargo}</p>
                      </div>
                    </div>
                  </div>

                  {/* Highlights */}
                  <div className="mb-8">
                    <h3 className="font-semibold mb-3">Key Highlights</h3>
                    <ul className="space-y-2">
                      {vehicle.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <ArrowRight className="h-5 w-5 text-secondary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Why Ethiopia */}
                  <div className="bg-muted/50 p-6 rounded-lg mb-8">
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <span>🇪🇹</span> Why This Car Fits Ethiopia
                    </h3>
                    <p className="text-muted-foreground">{vehicle.whyEthiopia}</p>
                  </div>

                  {/* CTA */}
                  <div className="flex flex-col sm:flex-row gap-3">
                    <Link to="/contact" className="flex-1">
                      <Button variant="premium" className="w-full">
                        Schedule Test Drive
                      </Button>
                    </Link>
                    <Link to="/contact" className="flex-1">
                      <Button variant="outline" className="w-full">
                        Request Quote
                      </Button>
                    </Link>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Experience Electric?
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Visit our showroom to see these vehicles in person and take them for a test drive.
          </p>
          <Link to="/contact">
            <Button variant="premium" size="xl">
              Book Showroom Visit
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Vehicles;

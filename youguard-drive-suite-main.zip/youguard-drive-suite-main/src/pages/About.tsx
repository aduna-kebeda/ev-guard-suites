import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Target, Heart, Users, TrendingUp, Award, Zap } from "lucide-react";

const About = () => {
  const values = [
    {
      icon: Target,
      title: "Excellence",
      description: "We deliver only the highest quality electric vehicles and service",
    },
    {
      icon: Heart,
      title: "Customer First",
      description: "Your satisfaction and peace of mind are our top priorities",
    },
    {
      icon: TrendingUp,
      title: "Innovation",
      description: "Leading Ethiopia's transition to sustainable transportation",
    },
    {
      icon: Award,
      title: "Integrity",
      description: "Transparent pricing and honest recommendations always",
    },
  ];

  const leadership = [
    {
      name: "Samuel Tesfaye",
      role: "Chief Executive Officer",
      bio: "Visionary leader with 15+ years in automotive industry",
    },
    {
      name: "Rahel Alemayehu",
      role: "Operations Director",
      bio: "Expert in EV technology and sustainable mobility",
    },
    {
      name: "Daniel Kebede",
      role: "Service Manager",
      bio: "Certified EV technician with international training",
    },
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-muted/30 to-background">
        <div className="container mx-auto px-4 text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            About Kairos Addis + YouGuard
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            Powering Ethiopia's
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary"> Electric Revolution</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto animate-fade-in-up">
            We're on a mission to transform transportation in Ethiopia through premium 
            electric vehicles backed by exceptional warranty and service.
          </p>
        </div>
      </section>

      {/* Story */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">Our Story</h2>
            
            <div className="prose prose-lg max-w-none space-y-6 text-muted-foreground">
              <p>
                In 2023, <strong className="text-foreground">Kairos Addis</strong> and{" "}
                <strong className="text-foreground">YouGuard</strong> joined forces with a shared 
                vision: to bring world-class electric vehicles to Ethiopia while providing the warranty 
                and service infrastructure that gives customers complete peace of mind.
              </p>

              <p>
                <strong className="text-foreground">Kairos Addis</strong>, a pioneering automotive 
                dealer known for excellence in customer service, recognized early that electric vehicles 
                were the future of transportation. However, the transition required more than just 
                selling cars—it demanded comprehensive after-sales support.
              </p>

              <p>
                That's where <strong className="text-foreground">YouGuard</strong> came in. As Ethiopia's 
                leading warranty and service provider, YouGuard brought the technical expertise and 
                infrastructure needed to maintain these sophisticated electric vehicles. Together, we 
                created Ethiopia's first truly comprehensive EV dealership experience.
              </p>

              <Card className="bg-gradient-to-br from-primary/5 to-secondary/5 p-8 my-8 border-primary/20">
                <div className="flex items-start gap-4">
                  <Zap className="h-12 w-12 text-primary flex-shrink-0" />
                  <div>
                    <h3 className="text-xl font-semibold mb-2 text-foreground">Our Mission</h3>
                    <p className="text-muted-foreground">
                      To accelerate Ethiopia's transition to sustainable transportation by making 
                      premium electric vehicles accessible, reliable, and backed by exceptional 
                      service that exceeds international standards.
                    </p>
                  </div>
                </div>
              </Card>

              <p>
                Today, we're proud to have delivered over 2,000 electric vehicles to Ethiopian families 
                and businesses. Each vehicle comes with our industry-leading 5-year comprehensive warranty 
                and access to our network of EV-certified service centers across the country.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-12 text-center">Our Values</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <Card
                key={index}
                className="p-6 text-center hover:shadow-xl transition-all duration-300 hover:-translate-y-2"
              >
                <div className="bg-gradient-to-br from-primary/10 to-secondary/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <value.icon className="h-8 w-8 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{value.title}</h3>
                <p className="text-muted-foreground">{value.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">Leadership Team</h2>
          <p className="text-xl text-muted-foreground mb-12 text-center max-w-2xl mx-auto">
            Meet the passionate leaders driving Ethiopia's electric future
          </p>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {leadership.map((leader, index) => (
              <Card key={index} className="p-6 text-center hover:shadow-xl transition-all">
                <div className="w-24 h-24 rounded-full bg-gradient-to-br from-primary/20 to-secondary/20 mx-auto mb-4 flex items-center justify-center">
                  <Users className="h-12 w-12 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-1">{leader.name}</h3>
                <p className="text-sm text-primary mb-3">{leader.role}</p>
                <p className="text-muted-foreground text-sm">{leader.bio}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center text-primary-foreground">
            <div>
              <div className="text-5xl font-bold mb-2">2000+</div>
              <div className="text-primary-foreground/80">EVs Delivered</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">5 Years</div>
              <div className="text-primary-foreground/80">Warranty Coverage</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">98%</div>
              <div className="text-primary-foreground/80">Customer Satisfaction</div>
            </div>
            <div>
              <div className="text-5xl font-bold mb-2">24/7</div>
              <div className="text-primary-foreground/80">Support Available</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;

import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, 
  Shield, 
  Award, 
  Leaf, 
  Users, 
  TrendingUp,
  CheckCircle,
  ArrowRight,
  Battery,
  Wrench
} from "lucide-react";
import heroImage from "@/assets/hero-ev.jpg";
import evSuv from "@/assets/ev-suv.jpg";
import evSedan from "@/assets/ev-sedan.jpg";
import evCompact from "@/assets/ev-compact.jpg";

const Home = () => {
  const features = [
    {
      icon: Shield,
      title: "5-Year Warranty",
      description: "Comprehensive coverage for peace of mind",
    },
    {
      icon: Battery,
      title: "Long Range",
      description: "Up to 500km on a single charge",
    },
    {
      icon: Wrench,
      title: "Premium Service",
      description: "Expert EV maintenance and support",
    },
    {
      icon: Leaf,
      title: "Zero Emissions",
      description: "Clean energy for a better Ethiopia",
    },
  ];

  const vehicles = [
    {
      name: "Urban SUV",
      type: "Family Electric SUV",
      range: "450km",
      image: evSuv,
      price: "Starting from ETB 3,500,000",
    },
    {
      name: "Executive Sedan",
      type: "Premium Electric Sedan",
      range: "500km",
      image: evSedan,
      price: "Starting from ETB 4,200,000",
    },
    {
      name: "City Compact",
      type: "Urban Electric Compact",
      range: "350km",
      image: evCompact,
      price: "Starting from ETB 2,800,000",
    },
  ];

  const benefits = [
    "5-Year Comprehensive Warranty",
    "Free Home Charging Installation",
    "24/7 Roadside Assistance",
    "Regular Software Updates",
    "Dedicated Service Centers",
    "Trade-In Program Available",
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${heroImage})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/30" />
        </div>
        
        <div className="relative z-10 container mx-auto px-4">
          <div className="max-w-3xl animate-fade-in-up">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              Ethiopia's Premier EV Dealership
            </Badge>
            <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
              Drive the
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary"> Electric Future</span>
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-2xl">
              Experience premium electric vehicles with unmatched warranty and service. 
              Join Ethiopia's sustainable transportation revolution.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link to="/vehicles">
                <Button variant="premium" size="xl" className="w-full sm:w-auto">
                  Browse Vehicles
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/contact">
                <Button variant="outline" size="xl" className="w-full sm:w-auto">
                  Book Showroom Visit
                </Button>
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-primary rounded-full flex justify-center p-1">
            <div className="w-1 h-3 bg-primary rounded-full" />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fade-in">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Why Choose Kairos + YouGuard</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Premium electric vehicles backed by exceptional warranty and service
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <Card
                key={index}
                className="p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-2 bg-card border-border animate-scale-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="bg-gradient-to-br from-primary/10 to-secondary/10 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                  <feature.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-muted-foreground">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Vehicles */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12 animate-fade-in">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">Featured Electric Vehicles</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Discover our range of premium electric vehicles designed for Ethiopian roads
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {vehicles.map((vehicle, index) => (
              <Card
                key={index}
                className="overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 group animate-fade-in"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={vehicle.image}
                    alt={vehicle.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-secondary text-secondary-foreground">
                      {vehicle.range} Range
                    </Badge>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-2xl font-bold mb-2">{vehicle.name}</h3>
                  <p className="text-muted-foreground mb-4">{vehicle.type}</p>
                  <p className="text-lg font-semibold text-primary mb-4">{vehicle.price}</p>
                  <Link to="/vehicles">
                    <Button variant="default" className="w-full">
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link to="/vehicles">
              <Button variant="premium" size="lg">
                View All Vehicles
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in">
              <h2 className="text-3xl md:text-5xl font-bold mb-6">
                Complete Peace of Mind
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Every Kairos + YouGuard vehicle comes with comprehensive coverage and 
                support that sets new standards in Ethiopia's automotive industry.
              </p>
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle className="h-6 w-6 text-secondary flex-shrink-0" />
                    <span className="text-lg">{benefit}</span>
                  </div>
                ))}
              </div>
              <Link to="/services">
                <Button variant="default" size="lg" className="mt-8">
                  Learn About Our Services
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-2 gap-6 animate-scale-in">
              <Card className="p-8 text-center hover:shadow-xl transition-all">
                <Award className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="text-4xl font-bold mb-2">5 Years</h3>
                <p className="text-muted-foreground">Warranty Coverage</p>
              </Card>
              <Card className="p-8 text-center hover:shadow-xl transition-all">
                <Users className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-4xl font-bold mb-2">2000+</h3>
                <p className="text-muted-foreground">Happy Customers</p>
              </Card>
              <Card className="p-8 text-center hover:shadow-xl transition-all">
                <Zap className="h-12 w-12 text-secondary mx-auto mb-4" />
                <h3 className="text-4xl font-bold mb-2">100%</h3>
                <p className="text-muted-foreground">Electric Fleet</p>
              </Card>
              <Card className="p-8 text-center hover:shadow-xl transition-all">
                <TrendingUp className="h-12 w-12 text-accent mx-auto mb-4" />
                <h3 className="text-4xl font-bold mb-2">24/7</h3>
                <p className="text-muted-foreground">Support Available</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="relative overflow-hidden bg-gradient-to-r from-primary to-secondary p-12 md:p-16 text-center">
            <div className="absolute inset-0 opacity-10">
              <div className="absolute inset-0" style={{
                backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
                backgroundSize: '40px 40px'
              }} />
            </div>
            <div className="relative z-10 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-5xl font-bold text-primary-foreground mb-6">
                Ready to Go Electric?
              </h2>
              <p className="text-xl text-primary-foreground/90 mb-8">
                Visit our showroom to experience the future of transportation. 
                Our experts are ready to help you find your perfect electric vehicle.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/contact">
                  <Button variant="accent" size="xl" className="w-full sm:w-auto">
                    Book Showroom Visit
                  </Button>
                </Link>
                <Link to="/portal">
                  <Button 
                    variant="outline" 
                    size="xl" 
                    className="w-full sm:w-auto bg-white hover:bg-white/90 text-primary border-white"
                  >
                    Track Your Order
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Home;

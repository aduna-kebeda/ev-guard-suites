import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Wrench, 
  Battery, 
  CheckCircle, 
  Clock, 
  Phone,
  MapPin,
  Award,
  Zap
} from "lucide-react";
import { Link } from "react-router-dom";

const Services = () => {
  const warrantyFeatures = [
    "Complete battery and drivetrain coverage",
    "All electrical components and systems",
    "Software updates and diagnostics",
    "Roadside assistance 24/7",
    "Replacement vehicle during repairs",
    "Unlimited mileage warranty",
    "Transferable to new owner",
    "No hidden fees or deductibles",
  ];

  const services = [
    {
      icon: Battery,
      title: "Battery Health Monitoring",
      description: "Regular diagnostics to ensure optimal battery performance and longevity",
    },
    {
      icon: Wrench,
      title: "Scheduled Maintenance",
      description: "Comprehensive service packages to keep your EV running perfectly",
    },
    {
      icon: Zap,
      title: "Charging Solutions",
      description: "Home charging installation and consultation services",
    },
    {
      icon: Phone,
      title: "24/7 Support",
      description: "Round-the-clock assistance for any questions or emergencies",
    },
  ];

  const maintenanceSchedule = [
    { interval: "Every 10,000 km", service: "Basic inspection and tire rotation" },
    { interval: "Every 20,000 km", service: "Comprehensive system check and brake service" },
    { interval: "Every 40,000 km", service: "Major service including coolant and brake fluid" },
    { interval: "Annual", service: "Software updates and full diagnostic scan" },
  ];

  return (
    <div className="min-h-screen pt-16">
      {/* Hero */}
      <section className="py-20 bg-gradient-to-b from-muted/30 to-background">
        <div className="container mx-auto px-4 text-center">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            Warranty & Service Excellence
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
            5-Year Comprehensive
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-secondary"> Warranty & Service</span>
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto animate-fade-in-up">
            Industry-leading coverage and expert EV maintenance that keeps you driving with confidence
          </p>
        </div>
      </section>

      {/* Warranty Overview */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 bg-secondary/10 px-4 py-2 rounded-full mb-6">
                <Shield className="h-5 w-5 text-secondary" />
                <span className="font-semibold text-secondary">Ethiopia's Best EV Warranty</span>
              </div>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">
                Complete Peace of Mind for 5 Years
              </h2>
              <p className="text-lg text-muted-foreground mb-8">
                Our warranty goes beyond industry standards. We cover everything that matters, 
                with no surprises or hidden clauses. Drive with confidence knowing you're 
                completely protected.
              </p>
              <div className="space-y-4">
                {warrantyFeatures.map((feature, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <CheckCircle className="h-6 w-6 text-secondary flex-shrink-0 mt-0.5" />
                    <span className="text-lg">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            <Card className="p-8 lg:p-12 bg-gradient-to-br from-primary/5 to-secondary/5 border-primary/20">
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-gradient-to-br from-primary to-secondary mb-6">
                  <Award className="h-10 w-10 text-primary-foreground" />
                </div>
                <h3 className="text-3xl font-bold mb-2">5-Year / Unlimited km</h3>
                <p className="text-muted-foreground">Comprehensive Warranty</p>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                  <span className="font-medium">Battery & Drivetrain</span>
                  <CheckCircle className="h-5 w-5 text-secondary" />
                </div>
                <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                  <span className="font-medium">All Electrical Systems</span>
                  <CheckCircle className="h-5 w-5 text-secondary" />
                </div>
                <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                  <span className="font-medium">24/7 Roadside Assistance</span>
                  <CheckCircle className="h-5 w-5 text-secondary" />
                </div>
                <div className="flex items-center justify-between p-4 bg-background rounded-lg">
                  <span className="font-medium">Software Updates</span>
                  <CheckCircle className="h-5 w-5 text-secondary" />
                </div>
              </div>

              <Link to="/contact">
                <Button variant="premium" size="lg" className="w-full mt-8">
                  Learn More About Warranty
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* Services */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Our Services</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Expert EV maintenance and support from certified technicians
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="p-6 hover:shadow-xl transition-all hover:-translate-y-2">
                <div className="bg-gradient-to-br from-primary/10 to-secondary/10 w-14 h-14 rounded-xl flex items-center justify-center mb-4">
                  <service.icon className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
                <p className="text-muted-foreground">{service.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Maintenance Schedule */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Maintenance Schedule</h2>
              <p className="text-xl text-muted-foreground">
                Simple, predictable service intervals to keep your EV in perfect condition
              </p>
            </div>

            <div className="space-y-4">
              {maintenanceSchedule.map((item, index) => (
                <Card key={index} className="p-6 hover:shadow-lg transition-all">
                  <div className="flex items-center gap-6">
                    <div className="flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 flex-shrink-0">
                      <Clock className="h-8 w-8 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-1">{item.interval}</h3>
                      <p className="text-muted-foreground">{item.service}</p>
                    </div>
                    <Link to="/portal">
                      <Button variant="outline">Book Service</Button>
                    </Link>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Service Centers */}
      <section className="py-20 bg-muted/30">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Service Centers</h2>
            <p className="text-xl text-muted-foreground">
              EV-certified technicians ready to serve you
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="p-6">
              <MapPin className="h-8 w-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">Main Service Center</h3>
              <p className="text-muted-foreground mb-4">Bole Road, Addis Ababa</p>
              <p className="text-sm text-muted-foreground">Mon-Sat: 8:00 AM - 6:00 PM</p>
            </Card>

            <Card className="p-6">
              <MapPin className="h-8 w-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">Kazanchis Branch</h3>
              <p className="text-muted-foreground mb-4">Kazanchis, Addis Ababa</p>
              <p className="text-sm text-muted-foreground">Mon-Sat: 8:00 AM - 6:00 PM</p>
            </Card>

            <Card className="p-6">
              <MapPin className="h-8 w-8 text-primary mb-4" />
              <h3 className="font-semibold text-lg mb-2">Mobile Service</h3>
              <p className="text-muted-foreground mb-4">We come to you</p>
              <p className="text-sm text-muted-foreground">Available by appointment</p>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <Card className="relative overflow-hidden bg-gradient-to-r from-primary to-secondary p-12 md:p-16 text-center">
            <div className="relative z-10 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-5xl font-bold text-primary-foreground mb-6">
                Questions About Warranty or Service?
              </h2>
              <p className="text-xl text-primary-foreground/90 mb-8">
                Our team is here to help. Contact us today to learn more about our 
                comprehensive warranty and service packages.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/contact">
                  <Button variant="accent" size="xl">
                    Contact Us
                  </Button>
                </Link>
                <Link to="/portal">
                  <Button 
                    variant="outline" 
                    size="xl"
                    className="bg-white hover:bg-white/90 text-primary border-white"
                  >
                    Book Service Online
                  </Button>
                </Link>
              </div>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
};

export default Services;
